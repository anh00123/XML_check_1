# CSCU9T4-F_XMLpractical1
This repository holds the starter code for the first XML practical exercise in CSCU9T4 and F
